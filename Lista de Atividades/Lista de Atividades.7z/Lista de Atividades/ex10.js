/*
10 - Vetor de cores
Crie um vetor com 3 cores.
Depois:
● Adicione uma cor no final com push();
● Remova a primeira com shift();
● Exiba o vetor final no console.
*/

let cores=["azul", " vermelho ", " roxo"];

console.log(`O array de cores: ${cores}`);

cores.push(" rosa");
cores.shift;

console.log(`Array de cores após as alterações: ${cores}`);
